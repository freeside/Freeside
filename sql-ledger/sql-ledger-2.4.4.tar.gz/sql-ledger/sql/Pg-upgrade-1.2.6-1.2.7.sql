--
-- add the field shiptoemail to the customer table
--
alter table customer add column shiptoemail text;
